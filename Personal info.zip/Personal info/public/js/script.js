document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("personalInfoForm");

    form.addEventListener("submit", async function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Gather form data
        const formData = new FormData(form);
        const formDataObject = Object.fromEntries(formData.entries());

        try {
            // Send form data to the server
            const response = await fetch('/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formDataObject)
            }); 

            if (response.ok) {
                alert("Form submitted successfully!");
                form.reset(); // Reset the form after successful submission
            } else {
                alert("Error submitting form.");
            }
        } catch (error) {
            alert("Error submitting form.");
        }
    });
});
