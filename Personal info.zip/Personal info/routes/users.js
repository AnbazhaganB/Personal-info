const express = require('express');
const router = express.Router();
const User = require('../models/users');

// Endpoint to create a new user
router.post('/users', async (req, res) => {
    try {
        // Destructure user details from request body
        const { name, email, contact, DOB, gender, country, address } = req.body;

        // Check if all required fields are present
        if (!name || !email || !contact || !DOB || !gender || !country || !address) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        // Validate contact number (assuming it's a 10-digit number)
        if (!/^\d{10}$/.test(contact)) {
            return res.status(400).json({ error: 'Please enter a valid 10 digit contact number' });
        }

        // Create a new user instance
        const newUser = new User({ name, email, contact, DOB, gender, country, address });

        // Save the new user to the database
        const savedUser = await newUser.save();

        // Respond with the newly created user
        res.status(201).json(savedUser);
    } catch (err) {
        // Handle database errors or other exceptions
        console.error('Error creating user:', err);
        res.status(500).json({ error: 'Error creating user' });
    }
});

module.exports = router;





// const express = require('express');
// const router = express.Router();
// const User = require('../models/users');

// // Endpoint to create a new user
// router.post('/users', async (req, res) => {
//   try {
//     const { name, email, contact, DOB, gender, country, address } = req.body;

//     // Create a new user
//     const newUser = new User({ name, email, contact, DOB, gender, country, address });
//     await newUser.save();

//     res.status(201).json(newUser); // Respond with the newly created user
//   } catch (err) {
//     res.status(500).send(err);
//   }
// });

// module.exports = router;