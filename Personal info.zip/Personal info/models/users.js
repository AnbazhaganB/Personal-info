const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  contact: {
    type: String,
    required: true,
    match: [/^\d{10}$/, 'Please enter a valid 10 digit contact number']
  },
  DOB: {
    type: Date,
    required: true
  },
  gender: {
    type: String,
    required: true
  },
  country: {
    type: String,
    required: true
  },
  address: {
    type: String,
    required: true
  }
}, { collection: 'users' });  // Specify the collection name

const User = mongoose.model('User', userSchema);
module.exports = User;
