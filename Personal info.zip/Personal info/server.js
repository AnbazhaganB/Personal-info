const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
require('dotenv').config();  // Load environment variables

const app = express();
const port = process.env.PORT || 8000;  // Use the PORT from .env or default to 8000

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/personalinfo', {  // Use the MONGODB_URI from .env
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('Error connecting to MongoDB:', err);
});

// Middleware to parse JSON bodies
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// // Use CORS middleware
// app.use(cors());
app.options('*', cors()); // Enable preflight for all routes

// Serve static files (e.g., HTML form)
app.use(express.static(path.join(__dirname, 'public')));

// Use routes
const userRoutes = require('./routes/users');
app.use(userRoutes);

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});