personal-info-project/
├── public/
│   ├── index.html
│   └── css/
│       └── style.css
│   └── js/
│       └── script.js
├── routes/
│   └── users.js
├── models/
│   └── user.js
├── server.js
├── package.json
└── README.md


# Personal Info Project

## Description

A simple project to collect and store personal information using a form.

## Usage

1. Open your browser and navigate to `http://localhost:8000`
2. Fill out the form and submit your information
